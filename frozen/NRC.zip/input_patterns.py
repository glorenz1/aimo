"""Small input-only lexical screens; these are proxies, not mathematical parses.

No outcomes, reference solutions, answer traces, or corpus-fitted quantities are
read here. The caller fits all preprocessing and prediction inside its folds.
"""
from __future__ import annotations

import collections
import math
import re


VERSION = "input-structure-screens-v1"
CONTROL_KEYS = ["text_loglength", "text_number_count"]
NUMBER = re.compile(r"(?<![A-Za-z])[-+]?\d+(?:\.\d+)?")
WORD = re.compile(r"[A-Za-z]+")
REQUEST = re.compile(r"\b(?:find|determine|compute|calculate|evaluate|what|how many|prove|show)\b", re.I)
MATH = re.compile(r"\$[^$]*\$|\\\([^\n]*?\\\)|\\\[[\s\S]*?\\\]")
IDENTIFIER = re.compile(r"(?<![A-Za-z\\])[A-Za-z](?:_\{?[A-Za-z0-9]+\}?)?(?![A-Za-z])")
UNIT = re.compile(r"\b(?:cm|mm|km|meters?|metres?|centimeters?|centimetres?|inches?|feet|foot|miles?|hours?|minutes?|seconds?|grams?|kilograms?|liters?|litres?|dollars?|cents?|degrees?)\b", re.I)
STOP = set("a an the of to in is are be and or if for with on at by from that this these those let find determine compute calculate evaluate what how many its their as it has have such then given".split())


def count(pattern: str, text: str) -> int:
    return len(re.findall(pattern, text, re.I))


def ratio(a: float, b: float) -> float:
    return float(a) / max(float(b), 1.0)


def nesting(text: str, pairs: str) -> tuple[int, float, int]:
    """Lexical nesting only; unmatched delimiters do not certify invalid math."""
    opens = pairs[::2]; closes = pairs[1::2]
    matching = dict(zip(closes, opens)); stack = []; depths = []; unmatched = 0
    for char in text:
        if char in opens:
            stack.append(char); depths.append(len(stack))
        elif char in closes:
            if stack and stack[-1] == matching[char]:
                stack.pop()
            else:
                unmatched += 1
    return max(depths, default=0), ratio(sum(depths), len(depths)), unmatched + len(stack)


def overlap(a: set, b: set) -> float:
    return ratio(len(a & b), len(a | b))


def one(text: str) -> dict[str, float]:
    words = WORD.findall(text.lower()); nw = max(len(words), 1); length = max(len(text), 1)
    numbers = list(NUMBER.finditer(text)); tokens = [m.group() for m in numbers]
    # Magnitudes are log-transformed before subtraction, avoiding large-float
    # ratios for long integer literals. They are surface values, not solutions.
    magnitudes = []
    for token in tokens:
        value = abs(float(token))
        if math.isfinite(value):
            magnitudes.append(math.log1p(value))
        else:
            magnitudes.append(float(len(token.lstrip("+-"))) * math.log(10))
    freq = collections.Counter(tokens)
    spans = list(MATH.finditer(text)); math_text = " ".join(m.group() for m in spans)
    identifiers = IDENTIFIER.findall(math_text); unique_ids = set(identifiers)
    idfreq = collections.Counter(identifiers)
    requests = list(REQUEST.finditer(text)); request_start = requests[-1].start() if requests else len(text)
    premise, target = text[:request_start], text[request_start:]
    content = lambda s: {w for w in WORD.findall(s.lower()) if w not in STOP and len(w) > 2}
    target_ids = set(IDENTIFIER.findall(" ".join(m.group() for m in MATH.finditer(target))))
    premise_ids = set(IDENTIFIER.findall(" ".join(m.group() for m in MATH.finditer(premise))))
    sentences = [s for s in re.split(r"[.!?;\n]+", text) if s.strip()]
    sentence_numbers = [len(NUMBER.findall(s)) for s in sentences]
    numeric_sentences = sum(n > 0 for n in sentence_numbers)
    numeric_entropy = 0.0
    if sum(sentence_numbers):
        for n in sentence_numbers:
            p = n / sum(sentence_numbers)
            if p:
                numeric_entropy -= p * math.log(p)
        numeric_entropy /= max(math.log(max(len(sentences), 2)), 1e-12)
    units = [m.group().lower() for m in UNIT.finditer(text)]
    nearby_units = sum(bool(UNIT.search(text[m.end():m.end() + 24])) for m in numbers)
    # A numeric literal's local identifiers provide an ambiguity proxy. This
    # deliberately makes no semantic quantity-to-entity assignment.
    local_ids = [set(IDENTIFIER.findall(text[max(0, m.start()-32):m.end()+32])) for m in numbers]
    ambiguous = sum(len(s) > 1 for s in local_ids)
    unidentified = sum(not s for s in local_ids)
    depth, mean_depth, unmatched = nesting(math_text, "{}()[]")
    pdepth, _, _ = nesting(text, "()")
    code = list(re.finditer(r"\\begin\{(?:tikzpicture|asy|verbatim|lstlisting)\}[\s\S]*?\\end\{(?:tikzpicture|asy|verbatim|lstlisting)\}|\[asy\][\s\S]*?\[/asy\]|```[\s\S]*?```", text, re.I))
    commands = re.findall(r"\\[A-Za-z]+", text)
    sentence_id_sets = [set(IDENTIFIER.findall(" ".join(m.group() for m in MATH.finditer(s)))) for s in sentences]
    cooccurrences = sum(len(s) * (len(s)-1) / 2 for s in sentence_id_sets)
    d = {
        "text_loglength": math.log1p(len(text)),
        "text_number_count": float(len(numbers)),
        "scope_conditionals": float(count(r"\b(?:if|provided|whenever|unless|assuming)\b", text)),
        "scope_disjunctions": float(count(r"\b(?:or|either)\b", text)),
        "scope_quantifiers": float(count(r"\b(?:each|every|all|any|exactly|at least|at most|unique)\b", text)),
        "domain_integrality": float(count(r"\b(?:integer|integers|integral|natural|whole|prime)\b", text)),
        "domain_sign": float(count(r"\b(?:positive|negative|nonnegative|nonzero|real|complex)\b", text)),
        "domain_distinctness": float(count(r"\b(?:distinct|different|consecutive|coprime)\b", text)),
        "scope_negations": float(count(r"\b(?:not|no|never|neither|without)\b", text)),
        "scope_exceptions": float(count(r"\b(?:except|excluding|other than|unless)\b", text)),
        "relations_equality": float(text.count("=") + count(r"\b(?:equals?|equal to|is the same as)\b", text)),
        "relations_inequality": float(count(r"[<>]|\\(?:leq?|geq?|neq)\b|\b(?:less than|greater than|at least|at most)\b", text)),
        "number_unique_fraction": ratio(len(freq), len(tokens)),
        "number_max_repeat_fraction": ratio(max(freq.values(), default=0), len(tokens)),
        "number_logrange": max(magnitudes, default=0) - min(magnitudes, default=0),
        "number_negative_fraction": ratio(sum(t.startswith("-") for t in tokens), len(tokens)),
        "number_decimal_fraction": ratio(sum("." in t for t in tokens), len(tokens)),
        "binding_local_ambiguity": ratio(ambiguous, len(numbers)),
        "binding_local_unidentified": ratio(unidentified, len(numbers)),
        "binding_number_identifier_ratio": ratio(len(numbers), len(identifiers)),
        "units_distinct": float(len(set(units))),
        "units_numeric_attachment": ratio(nearby_units, len(numbers)),
        "units_density": ratio(len(units), nw),
        "symbol_depth_max": float(depth),
        "symbol_depth_mean": mean_depth,
        "symbol_unmatched": float(unmatched),
        "symbol_fraction_count": float(count(r"\\(?:d?frac|tfrac)\b|\d+\s*/\s*\d+", text)),
        "symbol_root_count": float(count(r"\\sqrt\b|\b(?:square root|cube root)\b", text)),
        "symbol_aggregate_count": float(count(r"\\(?:sum|prod|int)\b", text)),
        "symbol_power_count": float(text.count("^") + count(r"\b(?:squared|cubed|power)\b", text)),
        "symbol_subscripts": float(math_text.count("_")),
        "symbol_indexed_ids": float(sum("_" in t for t in identifiers)),
        "symbol_identifier_count": float(len(unique_ids)),
        "symbol_identifier_reuse": ratio(sum(n-1 for n in idfreq.values()), len(identifiers)),
        "symbol_local_coupling": ratio(cooccurrences, len(sentences)),
        "target_start_fraction": ratio(request_start, length),
        "target_span_fraction": ratio(len(target), length),
        "target_request_count": float(len(requests)),
        "target_connectives": float(count(r"\b(?:and|or|such that|where)\b", target)),
        "target_quantity_nouns": float(count(r"\b(?:area|length|volume|number|sum|product|probability|remainder|value|ratio|maximum|minimum)\b", target)),
        "target_word_overlap": overlap(content(target), content(premise)),
        "target_symbol_overlap": overlap(target_ids, premise_ids),
        "target_proof_request": float(bool(re.search(r"\b(?:prove|show that|demonstrate)\b", target, re.I))),
        "target_extremal_request": float(bool(re.search(r"\b(?:largest|smallest|maximum|minimum|greatest|least)\b", target, re.I))),
        "target_count_request": float(bool(re.search(r"\b(?:how many|number of|ways)\b", target, re.I))),
        "composition_sentence_count": float(len(sentences)),
        "composition_numeric_sentence_fraction": ratio(numeric_sentences, len(sentences)),
        "composition_numeric_entropy": numeric_entropy,
        "composition_case_count": float(count(r"\b(?:case|cases|otherwise|respectively)\b", text)),
        "composition_enumerated_count": float(count(r"(?:^|\n)\s*(?:\(?[a-dA-Di-vI-V]\)|\d+[.)]|[-*])\s", text)),
        "composition_reference_count": float(count(r"\b(?:it|its|they|their|this|that|these|those|former|latter|above|below)\b", text)),
        "composition_reference_span": ratio(request_start, max(len(sentences), 1)),
        "composition_order_count": float(count(r"\b(?:before|after|then|first|next|last|previous|subsequent|successive)\b", text)),
        "composition_recurrence_count": float(count(r"\b(?:sequence|recursive|recurrence|recursively|iteration|iterative)\b", text)),
        "layout_code_fraction": ratio(sum(m.end()-m.start() for m in code), length),
        "layout_command_density": ratio(len(commands), length),
        "layout_diagram_markers": float(count(r"\\(?:draw|coordinate|node|path)\b|\b(?:diagram|figure|shown)\b", text)),
        "layout_newline_density": ratio(text.count("\n"), length),
        "layout_paragraph_count": float(len(re.findall(r"\n\s*\n", text))),
        "layout_inline_math_fraction": ratio(sum(m.end()-m.start() for m in spans), length),
        "layout_parenthetical_depth": float(pdepth),
        "layout_parenthetical_fraction": ratio(sum(len(m.group()) for m in re.finditer(r"\([^()]*\)", text)), length),
    }
    if not all(math.isfinite(v) for v in d.values()):
        raise ValueError("nonfinite input-only feature")
    return d


def specifications() -> list[dict]:
    entries = [
        ("scope_logic", "constraint_scope", "Conditional, disjunctive and quantified premises add a failure mode beyond shadow.", ["scope_conditionals", "scope_disjunctions", "scope_quantifiers"]),
        ("scope_domains", "constraint_scope", "Explicit integrality, sign and distinctness restrictions predict fragility beyond shadow.", ["domain_integrality", "domain_sign", "domain_distinctness"]),
        ("scope_exceptions", "constraint_scope", "Negations and exceptions identify constraints that shadow underweights.", ["scope_negations", "scope_exceptions"]),
        ("scope_relations", "constraint_scope", "Equality versus inequality burden supplies a complementary constraint signal.", ["relations_equality", "relations_inequality"]),
        ("quantity_collision", "quantity_binding", "Repeated numeric literals create quantity-binding ambiguity beyond numerical count.", ["number_unique_fraction", "number_max_repeat_fraction"]),
        ("quantity_scale", "quantity_binding", "Magnitude heterogeneity and signed or decimal literals mark numerical fragility.", ["number_logrange", "number_negative_fraction", "number_decimal_fraction"]),
        ("quantity_local_binding", "quantity_binding", "The local identifier environment of quantities predicts binding difficulty.", ["binding_local_ambiguity", "binding_local_unidentified", "binding_number_identifier_ratio"]),
        ("quantity_units", "quantity_binding", "Multiple unit types and weak local unit attachment add quantity-relation information.", ["units_distinct", "units_numeric_attachment", "units_density"]),
        ("symbol_nesting", "symbolic_burden", "Nested symbolic notation adds predictive information beyond total length.", ["symbol_depth_max", "symbol_depth_mean", "symbol_unmatched"]),
        ("symbol_operations", "symbolic_burden", "Fractions, roots, powers and aggregates expose different symbolic demands.", ["symbol_fraction_count", "symbol_root_count", "symbol_power_count", "symbol_aggregate_count"]),
        ("symbol_indexing", "symbolic_burden", "Indexed quantities expose a distinct variable-tracking demand.", ["symbol_subscripts", "symbol_indexed_ids"]),
        ("symbol_coupling", "symbolic_burden", "The number, reuse and local coupling of mathematical identifiers predict fragility.", ["symbol_identifier_count", "symbol_identifier_reuse", "symbol_local_coupling"]),
        ("target_location", "target_structure", "Dispersed or late requested targets reveal a target-selection failure mode.", ["target_start_fraction", "target_request_count"]),
        ("target_composition", "target_structure", "Compound requests and multiple requested quantity types predict target confusion.", ["target_connectives", "target_quantity_nouns"]),
        ("target_premise_alignment", "target_structure", "Weak lexical or symbolic overlap between target and premises predicts fragility.", ["target_word_overlap", "target_symbol_overlap"]),
        ("target_task_kind", "target_structure", "Proof, extremal and counting requests have residual risks after shadow.", ["target_proof_request", "target_extremal_request", "target_count_request"]),
        ("premise_dispersion", "compositional_structure", "The distribution of numerical premises across sentences predicts integration difficulty.", ["composition_sentence_count", "composition_numeric_sentence_fraction", "composition_numeric_entropy"]),
        ("premise_cases", "compositional_structure", "Case and enumeration structure identifies a complementary compositional demand.", ["composition_case_count", "composition_enumerated_count"]),
        ("premise_references", "compositional_structure", "Reference expressions across a long premise span predict tracking difficulty.", ["composition_reference_count", "composition_reference_span"]),
        ("premise_order", "compositional_structure", "Ordered or recursive dependencies predict fragility beyond static symbolic burden.", ["composition_order_count", "composition_recurrence_count"]),
        ("layout_diagrams", "layout_source_confounds", "Diagram and source-code burden explains residual shadow errors as a source/layout proxy.", ["layout_code_fraction", "layout_command_density", "layout_diagram_markers"]),
        ("layout_fragmentation", "layout_source_confounds", "Paragraph and math-span fragmentation is a residual formatting/source signal.", ["layout_newline_density", "layout_paragraph_count", "layout_inline_math_fraction"]),
        ("layout_parentheticals", "layout_source_confounds", "Embedded parenthetical material predicts fragility beyond length.", ["layout_parenthetical_depth", "layout_parenthetical_fraction"]),
    ]
    out = []
    for name, family, hypothesis, keys in entries:
        out.append(dict(id="text_" + name, family=family, hypothesis=hypothesis, keys=keys,
            novelty="Small residual correction conditional on cross-fitted shadow; not the completed text/topic replacement classifier.",
            deployment="CPU regex/arithmetic on original input text; no additional model measurement.",
            control_keys=list(CONTROL_KEYS)))
    for name, family, hypothesis, keys, conditioning in [
        ("logic_confidence", "conditional_structure", "Logical-scope burden is useful specifically when shadow is uncertain rather than as a global additive effect.", ["scope_conditionals", "scope_disjunctions", "scope_quantifiers"], "confidence_gate"),
        ("binding_confidence", "conditional_structure", "Numeric collisions alter the reliability of shadow's score rather than only shifting its intercept.", ["number_unique_fraction", "binding_local_ambiguity"], "interaction"),
    ]:
        out.append(dict(id="text_" + name, family=family, hypothesis=hypothesis, keys=keys,
            novelty="Explicit confidence-conditional hypothesis versus the corresponding additive structural block.",
            deployment="Same original-input CPU features plus the existing shadow score.",
            control_keys=list(CONTROL_KEYS), conditioning=conditioning))
    return out


def build(rows) -> tuple[dict, list[dict], dict]:
    rows = list(rows); values = {}
    for row in rows:
        if row["row_id"] in values:
            raise ValueError("duplicate input row_id")
        # Deliberately do not copy or inspect any outcome/source-answer field.
        values[row["row_id"]] = one(row["problem"])
    specs = specifications()
    return values, specs, dict(version=VERSION, rows=len(values), screens=len(specs),
        inputs_read=["row_id", "problem"], labels_read=False, target_generations=0,
        additional_model_measurements=0, external_services=False,
        interpretation="Lexical structural proxies, not verified semantic bindings or proofs.",
        learned_preprocessing="None here; caller must fit normalization and correction inside grouped training folds.")
