"""Deployable text/role definitions and FP64 summaries of qualified token states.

No outcomes, solution annotations or learned parameters enter these functions.
Layer31 is canonical BF16; native layer summaries are separately qualified FP16.
"""
import collections
import itertools
import math
import re
import numpy as np
from input_patterns import NUMBER,REQUEST,MATH

EPS=1e-30
F01=['number_logrange','number_negative_fraction','number_decimal_fraction','contextual_update_alignment']
REL=re.compile(r'[=<>]|\\(?:leq?|geq?|ne?q|equiv|cong|sim|mid|parallel|perp)\b|\b(?:equals?|less than|greater than|positive|integer|distinct)\b',re.I)
IDENT=re.compile(r'(?<![A-Za-z])[A-Za-z](?:_\{?[A-Za-z0-9]+\}?)?(?![A-Za-z])')


def symbols(s):
    s=re.sub(r'\\[A-Za-z]+',' ',s)
    return IDENT.findall(s)
def ratio(a,b):return float(a)/max(float(b),1.)
def cos(a,b):return float(np.dot(a,b)/max(np.linalg.norm(a)*np.linalg.norm(b),EPS))
def spans(pattern,text):return [(m.start(),m.end()) for m in pattern.finditer(text)]
def atom(s,i):
    while i<len(s) and s[i].isspace():i+=1
    if i>=len(s):return '',i
    if s[i]!='{':return s[i],i+1
    start=i+1;depth=1;i+=1
    while i<len(s) and depth:
        depth+=(s[i]=='{')-(s[i]=='}');i+=1
    return s[start:i-1],i


def text_features(text):
    d={}; families=[]
    def family(name,prior,hypothesis,blocks):
        families.append(dict(name=name,prior=prior,hypothesis=hypothesis,blocks=blocks,source='input_text'))
    def put(prefix,vals):
        d.update({prefix+'_'+k:float(v) for k,v in vals.items()})
    fr=[]
    for m in re.finditer(r'\\(?:d?frac|tfrac)',text):
        a,j=atom(text,m.end());b,_=atom(text,j);fr.append((a,b))
    for m in re.finditer(r'(?<!\d)(\d+)\s*/\s*(\d+)',text):fr.append((m[1],m[2]))
    numeric=lambda s:[float(v) for v in NUMBER.findall(s) if math.isfinite(float(v))]
    den=[v for _,b in fr for v in numeric(b)];num=[v for a,_ in fr for v in numeric(a)]
    logs=lambda vs:[math.log1p(abs(v)) for v in vs]
    put('frac',dict(den_symbols=ratio(sum(bool(symbols(b)) for _,b in fr),len(fr)),den_variables=sum(len(set(symbols(b))) for _,b in fr),
        role_overlap=np.mean([ratio(len(set(symbols(a))&set(symbols(b))),len(set(symbols(a))|set(symbols(b)))) for a,b in fr]) if fr else 0,
        role_asymmetry=sum(len(set(symbols(a)))-len(set(symbols(b))) for a,b in fr),
        nested=sum('frac' in a or 'frac' in b for a,b in fr),operator_asymmetry=sum(a.count('+')+a.count('-')-b.count('+')-b.count('-') for a,b in fr),
        denominator_logmean=np.mean(logs(den)) if den else 0,role_logcontrast=(np.mean(logs(num)) if num else 0)-(np.mean(logs(den)) if den else 0),
        present=bool(fr)))
    family('fraction_expression','text_symbol_operations','Numerator/denominator roles expose structure beyond counting fraction glyphs.',
        [['frac_den_symbols','frac_den_variables'],['frac_role_overlap','frac_role_asymmetry'],['frac_nested','frac_operator_asymmetry'],['frac_denominator_logmean','frac_role_logcontrast']])
    ex=[]
    for m in re.finditer(r'\^',text):
        a,_=atom(text,m.end());ex.append(a)
    exnum=[v for a in ex for v in numeric(a)]
    put('power',dict(symbolic=ratio(sum(bool(symbols(a)) for a in ex),len(ex)),negative=sum(a.lstrip().startswith('-') for a in ex),
        nested=sum('^' in a for a in ex),operators=sum(a.count('+')+a.count('-') for a in ex),
        exponent_logmax=max(logs(exnum),default=0),exponent_logspread=np.std(logs(exnum)) if exnum else 0,
        repeated=ratio(len(ex)-len(set(ex)),len(ex)),variable_coupling=sum(len(set(symbols(a))) for a in ex)))
    family('power_expression','text_quantity_scale','Exponent roles and symbolic exponents differ from raw literal magnitude.',
        [['power_symbolic','power_negative'],['power_nested','power_operators'],['power_exponent_logmax','power_exponent_logspread'],['power_repeated','power_variable_coupling']])
    mt=' '.join(m.group() for m in MATH.finditer(text));sy=symbols(mt);freq=collections.Counter(sy)
    operators=collections.Counter(re.findall(r'[+\-*/^=]',mt)); terms=re.split(r'[+=]',mt)
    put('algebra',dict(add_product_balance=(operators['+']+operators['-']-operators['*']-operators['/'])/max(len(mt),1),
        implicit_products=len(re.findall(r'\d\s*[A-Za-z]|[A-Za-z]\s*\(',mt)),
        variable_inequality=ratio(len(set(sy)),len(sy)),term_variable_spread=np.std([len(set(symbols(t))) for t in terms]) if terms else 0,
        coefficient_adjacency=len(re.findall(r'\d+\s*(?:[A-Za-z]|\\[a-z]+)',mt)),operator_transitions=len(re.findall(r'[+\-*/^]\s*[+\-*/^]',mt)),
        equality_term_asymmetry=np.std([len(t) for t in re.split('=',mt)]) if mt else 0,nonlinear_variable_pairs=len(re.findall(r'[A-Za-z]\s*[*^]\s*[A-Za-z0-9]',mt))))
    family('algebraic_expression','text_symbol_coupling','Operator/term structure supplies expression demand rather than symbol counts.',
        [['algebra_add_product_balance','algebra_implicit_products'],['algebra_variable_inequality','algebra_term_variable_spread'],['algebra_coefficient_adjacency','algebra_operator_transitions'],['algebra_equality_term_asymmetry','algebra_nonlinear_variable_pairs']])
    nn=numeric(text);ll=logs(nn);delta=np.diff(ll)
    sent=re.split(r'[.;\n]',text)
    clusters=[numeric(s) for s in sent]
    put('localnum',dict(adjacent_jump=np.mean(abs(delta)) if len(delta) else 0,adjacent_signed=np.mean(delta) if len(delta) else 0,
        sentence_logspread=np.mean([np.std(logs(x)) for x in clusters if x]) if nn else 0,
        cross_sentence_repeat=ratio(sum(len(set(NUMBER.findall(s))) for s in sent)-len(set(NUMBER.findall(text))),len(nn)),
        small_integer_fraction=ratio(sum(abs(v)<=9 and v==int(v) for v in nn),len(nn)),large_small_ratio=ratio(sum(abs(v)>=100 for v in nn),sum(0<abs(v)<10 for v in nn)),
        adjacent_repeat=ratio(sum(a==b for a,b in zip(nn,nn[1:])),max(len(nn)-1,0)),zero_one_fraction=ratio(sum(abs(v) in [0,1] for v in nn),len(nn))))
    family('local_numeric_relations','text_quantity_scale','Local numerical organization differs from F01’s global range and singleton flags.',
        [['localnum_adjacent_jump','localnum_adjacent_signed'],['localnum_sentence_logspread','localnum_cross_sentence_repeat'],['localnum_small_integer_fraction','localnum_large_small_ratio'],['localnum_adjacent_repeat','localnum_zero_one_fraction']])
    edges=set();nodes=set(sy);hyper=[]
    for m in MATH.finditer(text):
        ss=set(symbols(m.group()));hyper.append(ss);edges.update(tuple(sorted(x)) for x in itertools.combinations(ss,2))
    degree={x:sum(x in e for e in edges) for x in nodes};components=0;seen=set()
    for x in nodes:
        if x in seen:continue
        components+=1;todo=[x]
        while todo:
            v=todo.pop()
            if v in seen:continue
            seen.add(v);todo.extend(y for a,b in edges if v in [a,b] for y in [a,b] if y not in seen)
    ds=list(degree.values());total=sum(ds)
    put('graph',dict(density=ratio(2*len(edges),len(nodes)*(len(nodes)-1)),components=components,
        degree_cv=np.std(ds)/max(np.mean(ds),1) if ds else 0,degree_max=max(ds,default=0),
        hub_share=ratio(max(ds,default=0),total),degree_entropy=-sum((v/total)*math.log(v/total) for v in ds if v) if total else 0,
        isolated=ratio(sum(v==0 for v in ds),len(ds)),hyperedge_spread=np.std([len(s) for s in hyper]) if hyper else 0))
    family('symbol_cooccurrence_graph','text_symbol_coupling','Symbol graph connectivity and hubs expose coupled variable demands.',
        [['graph_density','graph_components'],['graph_degree_cv','graph_degree_max'],['graph_hub_share','graph_degree_entropy'],['graph_isolated','graph_hyperedge_spread']])
    equations=re.split(r'[.;\n]',mt);eq=[s for s in equations if REL.search(s)]
    es=[set(symbols(s)) for s in eq];reuse=collections.Counter(v for s in es for v in s)
    put('constraint',dict(arity_mean=np.mean([len(s) for s in es]) if es else 0,arity_spread=np.std([len(s) for s in es]) if es else 0,
        shared_variables=ratio(sum(v>1 for v in reuse.values()),len(reuse)),bottleneck=ratio(max(reuse.values(),default=0),len(eq)),
        equality_inequality_switches=len(re.findall(r'=[^=<>]*[<>]|[<>][^=<>]*=',mt)),chain_length=max([len(REL.findall(s)) for s in eq],default=0),
        disconnected_pairs=ratio(sum(not (a&b) for a,b in itertools.combinations(es,2)),len(es)*(len(es)-1)/2),single_variable=ratio(sum(len(s)==1 for s in es),len(es))))
    family('constraint_hypergraph','text_scope_relations','Constraint arity and shared-variable bottlenecks differ from equality counts.',
        [['constraint_arity_mean','constraint_arity_spread'],['constraint_shared_variables','constraint_bottleneck'],['constraint_equality_inequality_switches','constraint_chain_length'],['constraint_disconnected_pairs','constraint_single_variable']])
    req=list(REQUEST.finditer(text));start=req[-1].start() if req else len(text);target=text[start:];premise=text[:start]
    ts=set(symbols(' '.join(m.group() for m in MATH.finditer(target))))
    ps=set(symbols(' '.join(m.group() for m in MATH.finditer(premise))))
    td=[degree.get(v,0) for v in ts];others=[v for k,v in degree.items() if k not in ts]
    put('targetgraph',dict(degree=np.mean(td) if td else 0,degree_contrast=(np.mean(td) if td else 0)-(np.mean(others) if others else 0),
        novel_symbols=len(ts-ps),unconnected=ratio(sum(degree.get(v,0)==0 for v in ts),len(ts)),
        constraint_reach=ratio(sum(bool(s&ts) for s in es),len(es)),exclusive_constraints=ratio(sum(bool(s) and s<=ts for s in es),len(es)),
        operator_change=ratio(len(re.findall(r'[+*/^]',target)),len(target))-ratio(len(re.findall(r'[+*/^]',premise)),len(premise)),compound_symbols=len(ts)*len(re.findall(r'\band\b|,',target))))
    family('requested_variable_roles','text_target_premise_alignment','Requested variables’ graph roles and constraint reach predict target integration.',
        [['targetgraph_degree','targetgraph_degree_contrast'],['targetgraph_novel_symbols','targetgraph_unconnected'],['targetgraph_constraint_reach','targetgraph_exclusive_constraints'],['targetgraph_operator_change','targetgraph_compound_symbols']])
    clauses=re.split(r'[.;\n]',text);arity=[len(set(symbols(' '.join(m.group() for m in MATH.finditer(s))))) for s in clauses]
    q=[bool(re.search(r'\b(each|every|all|any|exactly)\b',s,re.I)) for s in clauses]
    neg=[bool(re.search(r'\b(not|no|without|except)\b',s,re.I)) for s in clauses]
    put('scopegraph',dict(quantified_arity=sum(a*b for a,b in zip(arity,q)),negated_arity=sum(a*b for a,b in zip(arity,neg)),
        shared_scope_variables=sum(len(set(symbols(a))&set(symbols(b))) for a,b in zip(clauses,clauses[1:]) if REL.search(a) and REL.search(b)),
        conditional_span=sum(len(s) for s in clauses if re.search(r'\bif\b',s,re.I))/max(len(text),1),
        late_constraint_fraction=ratio(sum(bool(REL.search(s)) for s in clauses[len(clauses)//2:]),sum(bool(REL.search(s)) for s in clauses)),
        exception_target=int(bool(re.search(r'\b(except|not|without)\b',target,re.I))),
        domain_variable_load=len(re.findall(r'\b(integer|real|positive|distinct)\b',text,re.I))*len(nodes),scope_switches=sum(a!=b for a,b in zip(q,q[1:]))))
    family('scoped_constraint_roles','text_scope_logic','Constraint scope weighted by variable load supplies relational information.',
        [['scopegraph_quantified_arity','scopegraph_negated_arity'],['scopegraph_shared_scope_variables','scopegraph_conditional_span'],['scopegraph_late_constraint_fraction','scopegraph_exception_target'],['scopegraph_domain_variable_load','scopegraph_scope_switches']])
    shingles=[tuple(sy[i:i+2]) for i in range(max(len(sy)-1,0))];cnt=collections.Counter(shingles)
    put('motif',dict(symbol_bigrams_repeated=ratio(sum(v-1 for v in cnt.values()),len(shingles)),symbol_runs=max([len(list(g)) for _,g in itertools.groupby(sy)],default=0),
        reversed_pairs=ratio(sum((b,a) in cnt for a,b in cnt),len(cnt)),alternating_pairs=sum(a==c and a!=b for a,b,c in zip(sy,sy[1:],sy[2:])),
        hyperedge_reuse=len(hyper)-len({tuple(sorted(s)) for s in hyper}),variable_burst=max(freq.values(),default=0)/max(len(sy),1),
        equation_lhs_reuse=len(re.findall(r'([A-Za-z])\s*=.*?\1\s*=',mt)),uppercase_lowercase_ratio=ratio(sum(s.isupper() for s in sy),sum(s.islower() for s in sy))))
    family('symbol_repetition_motifs','text_quantity_collision','Repeated and reversed symbol motifs expose tracking patterns beyond literal collisions.',
        [['motif_symbol_bigrams_repeated','motif_symbol_runs'],['motif_reversed_pairs','motif_alternating_pairs'],['motif_hyperedge_reuse','motif_variable_burst'],['motif_equation_lhs_reuse','motif_uppercase_lowercase_ratio']])
    depths=[];depth=0;deep_symbols=[]
    for c in mt:
        depth+=c in '{(['
        if c.isalpha():deep_symbols.append(depth)
        depths.append(depth);depth=max(0,depth-(c in '})]'))
    put('grouping',dict(symbol_depth=np.mean(deep_symbols) if deep_symbols else 0,deep_symbol_fraction=ratio(sum(v>=2 for v in deep_symbols),len(deep_symbols)),
        grouping_turns=sum(a!=b for a,b in zip(depths,depths[1:])),grouping_asymmetry=np.mean(depths[:len(depths)//2])-np.mean(depths[len(depths)//2:]) if len(depths)>1 else 0,
        relation_nesting=sum(mt[max(0,m.start()-12):m.start()].count('{') for m in REL.finditer(mt)),operator_nesting=sum(depths[i] for i,c in enumerate(mt) if c in '+-*/^'),
        set_braces=mt.count('\\{'),absolute_bars=mt.count('|')))
    family('algebraic_group_scopes','text_symbol_nesting','Which operations and symbols sit inside groups differs from maximum depth.',
        [['grouping_symbol_depth','grouping_deep_symbol_fraction'],['grouping_grouping_turns','grouping_grouping_asymmetry'],['grouping_relation_nesting','grouping_operator_nesting'],['grouping_set_braces','grouping_absolute_bars']])
    positions={name:[(a+b)/2/max(len(text),1) for a,b in spans(pattern,text)] for name,pattern in [('number',NUMBER),('relation',REL),('identifier',IDENT)]}
    for name,p in positions.items():put('position_'+name,dict(mean=np.mean(p) if p else 0,spread=np.std(p) if p else 0,tail=ratio(sum(x>.75 for x in p),len(p))))
    family('role_position_controls','N16','Positions of numbers, relations and identifiers are deployable controls for role sensitivity.',
        [['position_number_mean','position_relation_mean'],['position_number_spread','position_identifier_spread'],['position_relation_tail','position_number_tail'],['position_identifier_mean','position_relation_spread']])
    lengths=[len(m.group()) for m in MATH.finditer(text)];gaps=[];last=0
    for m in MATH.finditer(text):gaps.append(m.start()-last);last=m.end()
    put('partition',dict(math_burst=max(lengths,default=0)/max(sum(lengths),1),math_spread=np.std(lengths) if lengths else 0,
        prose_gap_max=max(gaps,default=0)/max(len(text),1),gap_spread=np.std(gaps) if gaps else 0,
        target_math_contrast=ratio(sum(len(m.group()) for m in MATH.finditer(target)),len(target))-ratio(sum(len(m.group()) for m in MATH.finditer(premise)),len(premise)),
        adjacent_math_runs=len(re.findall(r'\$\s*[,;:]?\s*\$',text)),
        relation_prose_contrast=len(REL.findall(text))-len(REL.findall(mt)),symbol_prose_contrast=len(symbols(text))-len(sy)))
    family('math_prose_partition','text_layout_fragmentation','Math/prose alternation and target-versus-premise balance differ from global source counts.',
        [['partition_math_burst','partition_math_spread'],['partition_prose_gap_max','partition_gap_spread'],['partition_target_math_contrast','partition_adjacent_math_runs'],['partition_relation_prose_contrast','partition_symbol_prose_contrast']])
    return d,families


def role_masks(row):
    text=row['problem'];start=row['original_span'][0];base=row['mask'];offsets=row['offsets']
    req=list(REQUEST.finditer(text));cut=req[-1].start() if req else len(text)
    intervals={'math':spans(MATH,text),'numeric':spans(NUMBER,text),'relation':spans(REL,text),
        'identifier':spans(IDENT,re.sub(r'\\([A-Za-z]+)',lambda m:' '*len(m.group()),text)),
        'request':[(cut,len(text))],'premise':[(0,cut)]}
    masks={'body':base}
    for name,ss in intervals.items():
        masks[name]=[i for i in base if any(offsets[i][1]>start+a and offsets[i][0]<start+b for a,b in ss)]
    n=len(base); masks['prefix']=base[:max(1,n//3)];masks['suffix']=base[-max(1,n//3):]
    for name in ['numeric','relation','request']:
        k=len(masks[name]);masks['matched_'+name]=[base[i] for i in np.linspace(0,max(n-1,0),k).astype(int)] if k else []
    return masks


def distribution(x):
    """FP64 sums/moments; no full D-by-D covariance or large learned map."""
    x=np.asarray(x,dtype=np.float64);n=len(x);d=x.shape[1]
    if n==0:return {k:0. for k in ['lognorm','norm_cv','norm_tail','norm_iqr','resultant','variance','var_concentration','mean_top8','mean_top64','mean_participation','mean_kurtosis','coordinate_skew','token_top8','mean_endpoint_cos','local_cos_mean','local_cos_sd','position_norm','adjacent_change','curvature','outlier_share','spectral_share','spectral_rank','norm_skew','norm_kurtosis']}
    norm=np.linalg.norm(x,axis=1);mean=x.mean(0);mu=float(norm.mean());sigma=float(norm.std());unit=x/np.maximum(norm[:,None],EPS)
    var=x.var(0);energy=mean**2;energy_total=max(float(energy.sum()),EPS)
    tokenenergy=x*x;te=np.maximum(tokenenergy.sum(1),EPS)
    local=np.sum(unit[:-1]*unit[1:],axis=1)
    centered=norm-mu
    # Fixed8coordinate-bin projection: deterministic, label-free sketch, not PCA.
    sketch=x.reshape(n,8,d//8).mean(2);s=sketch-sketch.mean(0)
    eig=np.maximum(np.linalg.eigvalsh(s.T@s/max(n,1)),0);eigtotal=max(float(eig.sum()),EPS)
    return dict(lognorm=math.log1p(mu),norm_cv=sigma/max(mu,EPS),norm_tail=float(np.quantile(norm,.95)/max(np.median(norm),EPS)),
        norm_iqr=float((np.quantile(norm,.75)-np.quantile(norm,.25))/max(mu,EPS)),
        resultant=float(np.linalg.norm(unit.mean(0))),variance=math.log1p(float(var.sum())),
        var_concentration=float(np.sort(var)[-64:].sum()/max(float(var.sum()),EPS)),
        mean_top8=float(np.sort(energy)[-8:].sum()/energy_total),mean_top64=float(np.sort(energy)[-64:].sum()/energy_total),
        mean_participation=float(energy_total**2/max(float((energy**2).sum()),EPS)/d),
        mean_kurtosis=float(np.mean((mean-mean.mean())**4)/max(float(np.var(mean))**2,EPS)),
        coordinate_skew=float(np.mean((mean-mean.mean())**3)/max(float(np.std(mean))**3,EPS)),
        token_top8=float(np.mean(np.partition(tokenenergy,-8,axis=1)[:,-8:].sum(1)/te)),
        mean_endpoint_cos=cos(mean,x[-1]),local_cos_mean=float(local.mean()) if len(local) else 0,
        local_cos_sd=float(local.std()) if len(local) else 0,
        position_norm=float(np.corrcoef(np.arange(n),norm)[0,1]) if n>1 and sigma>EPS else 0,
        adjacent_change=float(np.mean(np.linalg.norm(np.diff(x,axis=0),axis=1)/np.maximum(norm[:-1],EPS))) if n>1 else 0,
        curvature=float(np.mean(np.linalg.norm(np.diff(x,n=2,axis=0),axis=1))/max(mu,EPS)) if n>2 else 0,
        outlier_share=ratio(sum(norm>mu+2*sigma),n),spectral_share=float(eig[-1]/eigtotal),
        spectral_rank=float(eigtotal**2/max(float((eig**2).sum()),EPS))/8,
        norm_skew=float(np.mean(centered**3)/max(sigma**3,EPS)),norm_kurtosis=float(np.mean(centered**4)/max(sigma**4,EPS)))


def raw_features(row,states):
    masks=role_masks(row);x=np.asarray(states,float);e=x[-1];means={k:x[v].mean(0) if v else np.zeros(x.shape[1]) for k,v in masks.items()}
    stats={k:distribution(x[v]) for k,v in masks.items()};out={}
    for k,vals in stats.items():out.update({'bf31_'+k+'_'+name:v for name,v in vals.items()})
    for k,idx in masks.items():
        out['bf31_'+k+'_present']=float(bool(idx));out['bf31_'+k+'_endpoint']=cos(means[k],e)
        out['bf31_'+k+'_position']=float(np.mean(idx)/max(len(x)-1,1)) if idx else 0
    for a,b in [('numeric','relation'),('numeric','identifier'),('relation','request'),('math','request'),('premise','request'),('prefix','suffix')]:
        key='bf31_'+a+'_'+b
        out[key+'_cos']=cos(means[a],means[b]);out[key+'_normratio']=math.log(max(np.linalg.norm(means[a]),EPS)/max(np.linalg.norm(means[b]),EPS))
        out[key+'_endpoint_gap']=out['bf31_'+a+'_endpoint']-out['bf31_'+b+'_endpoint']
        out[key+'_translation']=cos(means[a]-means['body'],means[b]-means['body'])
    for role in ['numeric','relation','request']:
        for k in ['lognorm','resultant','mean_top8','mean_endpoint_cos']:
            out[f'bf31_{role}_position_matched_{k}']=stats[role][k]-stats['matched_'+role][k]
    fs=[]
    def f(name,hyp,blocks):fs.append(dict(name=name,prior='N01–N30 / F01',hypothesis=hyp,blocks=blocks,source='canonical_BF16_layer31_token_states'))
    key=lambda r,k:'bf31_'+r+'_'+k
    f('regional_norm_distributions','Token-norm distributions contain information that mean-vector norms discard.',
        [[key('body','lognorm'),key('body','norm_cv')],[key('math','norm_tail'),key('math','norm_iqr')],[key('numeric','norm_cv'),key('numeric','present')],[key('request','norm_tail'),key('request','norm_cv')]])
    f('directional_dispersion','Within-region directional agreement is distinct from endpoint/mean alignment.',
        [[key('body','resultant'),key('body','local_cos_sd')],[key('math','resultant'),key('numeric','resultant')],[key('request','resultant'),key('premise','resultant')],[key('relation','resultant'),key('relation','present')]])
    f('activation_concentration','Concentrated coordinate energy differs from the closed raw-norm studies.',
        [[key('body','mean_top8'),key('body','mean_top64')],[key('math','mean_participation'),key('math','token_top8')],[key('numeric','mean_top8'),key('numeric','token_top8')],[key('request','mean_participation'),key('request','token_top8')]])
    f('coordinate_tail_shape','Coordinate tail shape reflects different representation organization at a fixed boundary.',
        [[key('body','mean_kurtosis'),key('body','coordinate_skew')],[key('math','mean_kurtosis'),key('math','coordinate_skew')],[key('numeric','mean_kurtosis'),key('numeric','coordinate_skew')],[key('request','mean_kurtosis'),key('request','coordinate_skew')]])
    f('role_norm_allocation','Norm allocation between mathematical roles adds information beyond global magnitude.',
        [['bf31_numeric_relation_normratio','bf31_numeric_identifier_normratio'],['bf31_relation_request_normratio','bf31_math_request_normratio'],['bf31_premise_request_normratio','bf31_prefix_suffix_normratio'],[key('numeric','variance'),key('request','variance')]])
    f('mathematical_role_geometry','Specific numeric/relation/identifier geometry is finer than generic math/request pooling.',
        [['bf31_numeric_relation_cos','bf31_numeric_identifier_cos'],['bf31_relation_request_cos','bf31_math_request_cos'],['bf31_premise_request_cos','bf31_prefix_suffix_cos'],[key('relation','mean_participation'),key('identifier','resultant')]])
    f('role_endpoint_selection','The endpoint preferentially retains some explicit input roles.',
        [['bf31_numeric_relation_endpoint_gap','bf31_numeric_identifier_endpoint_gap'],['bf31_relation_request_endpoint_gap','bf31_math_request_endpoint_gap'],[key('numeric','endpoint'),key('relation','endpoint')],[key('request','endpoint'),key('premise','endpoint')]])
    f('centered_role_translation','Centering role means distinguishes relative relationships from common orientation.',
        [['bf31_numeric_relation_translation','bf31_numeric_identifier_translation'],['bf31_relation_request_translation','bf31_math_request_translation'],['bf31_premise_request_translation','bf31_prefix_suffix_translation'],[key('numeric','endpoint'), 'bf31_numeric_relation_translation']])
    f('position_matched_role_response','Role statistics differ from equal-count uniformly spaced position controls.',
        [[f'bf31_numeric_position_matched_{k}' for k in ['lognorm','resultant']], [f'bf31_relation_position_matched_{k}' for k in ['lognorm','resultant']],
         [f'bf31_request_position_matched_{k}' for k in ['mean_top8','mean_endpoint_cos']], [f'bf31_numeric_position_matched_{k}' for k in ['mean_top8','mean_endpoint_cos']]])
    f('token_position_norm_dynamics','Within-input radial trajectories differ from generated temporal norm traces.',
        [[key('body','position_norm'),key('body','norm_skew')],[key('prefix','lognorm'),key('suffix','lognorm')],[key('body','norm_kurtosis'),key('body','norm_iqr')],[key('math','position_norm'),key('numeric','position_norm')]])
    f('token_direction_dynamics','Within-prefill turning and local changes measure spatial propagation, not generated reasoning.',
        [[key('body','adjacent_change'),key('body','curvature')],[key('body','local_cos_mean'),key('body','local_cos_sd')],[key('math','adjacent_change'),key('request','adjacent_change')],[key('prefix','curvature'),key('suffix','curvature')]])
    f('fixed_sketch_spectrum','An eight-coordinate-bin covariance sketch measures distributional rank without a dictionary.',
        [[key('body','spectral_share'),key('body','spectral_rank')],[key('math','spectral_share'),key('math','spectral_rank')],[key('numeric','spectral_share'),key('numeric','spectral_rank')],[key('request','spectral_share'),key('request','spectral_rank')]])
    f('activation_outlier_localization','Variance and outliers localized to roles may complement average alignment.',
        [[key('body','outlier_share'),key('body','var_concentration')],[key('numeric','outlier_share'),key('numeric','var_concentration')],[key('relation','outlier_share'),key('relation','var_concentration')],[key('request','outlier_share'),key('request','var_concentration')]])
    return out,fs,masks


def native_features(row):
    vals={};a,b,c=row['selected_layers'];vv=row['vectors'];missing=set(row['missing'])
    def v(l,r):return None if f'{l}:{r}' in missing else np.asarray(vv[f'{l}:{r}'],float)
    for region in ['mathematical','requested','final_prompt']:
        vectors=[v(l,region) for l in [a,b,c]]
        for j,x in enumerate(vectors):
            if x is None:continue
            energy=x*x;total=max(float(energy.sum()),EPS)
            vals[f'fp16_{region}_L{j}_top16']=float(np.sort(energy)[-16:].sum()/total)
            vals[f'fp16_{region}_L{j}_participation']=total**2/max(float((energy*energy).sum()),EPS)/len(x)
        if all(x is not None for x in vectors):
            x,y,z=vectors
            vals[f'fp16_{region}_late_curvature']=cos(x,y)-cos(y,z)
            vals[f'fp16_{region}_terminal_retention']=cos(x,z)
    if all(v(l,r) is not None for l in [a,b,c] for r in ['mathematical','requested','final_prompt']):
        m,r,e=[v(a,k) for k in ['mathematical','requested','final_prompt']];mm,rr,ee=[v(b,k) for k in ['mathematical','requested','final_prompt']]
        dm,dr,de=mm-m,rr-r,ee-e
        vals.update(fp16_math_update_endpoint=cos(dm,de),fp16_request_update_endpoint=cos(dr,de),
            fp16_math_update_retention=cos(dm,mm),fp16_request_update_retention=cos(dr,rr),
            fp16_role_update_logratio=math.log(max(np.linalg.norm(dr),EPS)/max(np.linalg.norm(dm),EPS)),
            fp16_endpoint_update_logratio=math.log(max(np.linalg.norm(de),EPS)/max(np.linalg.norm(dm),EPS)))
    fs=[]
    def f(n,h,blocks):fs.append(dict(name=n,prior='N05–N14',hypothesis=h,blocks=blocks,source='native_FP16_three_layer_means; final RMS used only in dimensionless statistics'))
    f('native_layer_concentration','Dimensionless concentration profiles across native boundaries differ from raw growth.',
        [[f'fp16_mathematical_L{i}_top16' for i in [0,1]], [f'fp16_requested_L{i}_participation' for i in [0,1]],
         [f'fp16_final_prompt_L{i}_top16' for i in [0,1]], [f'fp16_requested_L{i}_top16' for i in [1,2]]])
    f('native_update_selectivity','Native role updates selectively align with endpoint changes.',
        [['fp16_math_update_endpoint','fp16_request_update_endpoint'],['fp16_math_update_retention','fp16_request_update_retention'],
         ['fp16_role_update_logratio','fp16_endpoint_update_logratio'],['fp16_math_update_endpoint','fp16_request_update_retention']])
    f('native_terminal_role_retention','Angular curvature/retention across native layers depends on token role.',
        [['fp16_mathematical_late_curvature','fp16_requested_late_curvature'],['fp16_requested_terminal_retention','fp16_final_prompt_terminal_retention'],
         ['fp16_mathematical_terminal_retention','fp16_final_prompt_late_curvature'],['fp16_requested_L2_participation','fp16_final_prompt_L2_top16']])
    return vals,fs


def opening_features(old):
    d={}
    pairs=[('logit_mass_deliberation','logit_mass_conclusion'),('logit_mass_numeric','logit_mass_word'),('logit_mass_mathematical','logit_mass_format')]
    for i,(a,b) in enumerate(pairs):d[f'opening_role_logbalance{i}']=math.log(max(old[a],EPS)/max(old[b],EPS))
    d['opening_competitor_tail_product']=old['logit_tail_secondary_dominance']*old['logit_tail_entropy']
    d['opening_spectrum_crossscale']=old['logit_head_slope']-old['logit_middle_slope']
    d['opening_lexical_math_balance']=d['opening_role_logbalance1']-d['opening_role_logbalance2']
    fs=[dict(name='opening_role_disagreement',prior='L01–L17',source='target_native_user_only_BF16_opening_logits; separate profile',
        hypothesis='Role log-odds and cross-scale contrasts differ from previously tested raw probability blocks.',
        blocks=[['opening_role_logbalance0','opening_role_logbalance1'],['opening_role_logbalance2','opening_lexical_math_balance'],
                ['opening_competitor_tail_product','opening_spectrum_crossscale'],['opening_role_logbalance0','opening_spectrum_crossscale']])]
    return d,fs
