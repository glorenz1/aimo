"""Experimental F01: one shared original-only BF16 forward; no generation.

Portable bundle includes frozen shadow.py/classifier.json and correction.json.
"""
import functools
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import time

_ROOT=Path(__file__).resolve().parent
_spec=importlib.util.spec_from_file_location('_f01_frozen_shadow',_ROOT/'shadow.py')
shadow=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(shadow)
MODELS=shadow.MODELS
_CORRECTION=None
NUMBER=re.compile(r'(?<![A-Za-z])[-+]?\d+(?:\.\d+)?')
MEASUREMENTS=dict(forwards=0,forward_seconds=0.,fallback_predictions=0,predictions=0)
OBSERVER=None  # Optional benchmark receipt writer; never changes predictions.


def correction():
    global _CORRECTION
    if _CORRECTION is None:
        _CORRECTION=json.loads((_ROOT/'correction.json').read_text())
        if _CORRECTION['schema']!='f01-experimental-correction-v1':
            raise ValueError('invalid experimental correction schema')
    return _CORRECTION


def numerical(problem):
    tokens=NUMBER.findall(problem); magnitudes=[]
    for token in tokens:
        v=abs(float(token))
        magnitudes.append(math.log1p(v) if math.isfinite(v) else len(token.lstrip('+-'))*math.log(10))
    return [max(magnitudes,default=0.)-min(magnitudes,default=0.),
        sum(t.startswith('-') for t in tokens)/max(len(tokens),1),
        sum('.' in t for t in tokens)/max(len(tokens),1)]


def problem_mask(prompt,problem,ids,offsets,special_ids):
    if not problem or prompt.count(problem)!=1:
        return []
    start=prompt.index(problem); end=start+len(problem)
    if len(ids)!=len(offsets): raise ValueError('offset/input length mismatch')
    return [i for i,(token,(a,b)) in enumerate(zip(ids,offsets))
        if b>a and a>=start and b<=end and token not in special_ids]


def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def anchored_alignment(lexical,contextual,endpoint):
    import numpy as np
    u=np.asarray(contextual,float)-np.asarray(lexical,float)
    v=np.asarray(endpoint,float)-np.asarray(lexical,float)
    nu,nv=float(np.linalg.norm(u)),float(np.linalg.norm(v))
    if nu==0 or nv==0 or not np.isfinite(u).all() or not np.isfinite(v).all(): return None
    return float(u@v/max(nu*nv,1e-30))


@functools.lru_cache(maxsize=20000)
def measure(problem):
    """Hook embedding output and decoder30; retain only pooled CPU summaries."""
    import numpy as np
    import torch
    tok,model=shadow._load(); start=time.perf_counter()
    prompt=shadow.build_prompt(tok,problem)
    encoded=tok(prompt,return_tensors='pt',truncation=True,return_offsets_mapping=True)
    ids=encoded['input_ids'][0].tolist(); offsets=encoded.pop('offset_mapping')[0].tolist()
    mask=problem_mask(prompt,problem,ids,offsets,set(tok.all_special_ids))
    inputs={k:v.to(model.device) for k,v in encoded.items()}
    need=correction()['name']=='F01'; observed={}
    def pool(output):
        # Preserve the historical FP32 NumPy reduction order exactly.
        return output[0,mask,:].detach().float().cpu().numpy().mean(axis=0,dtype=np.float32)
    def embedding_hook(_module,_args,output):
        if need and mask: observed['lexical']=pool(output)
    def layer_hook(_module,_args,output):
        if not isinstance(output,torch.Tensor): raise TypeError('unexpected Qwen3 decoder output')
        observed['endpoint']=output[0,-1,:].detach().float().cpu().numpy().copy()
        if need and mask: observed['contextual']=pool(output)
    handles=[]
    try:
        handles.append(model.model.layers[30].register_forward_hook(layer_hook))
        if need: handles.append(model.get_input_embeddings().register_forward_hook(embedding_hook))
        with torch.no_grad():
            output=model(**inputs,output_hidden_states=False,return_dict=True,use_cache=False,logits_to_keep=1)
        del output
    finally:
        for handle in handles: handle.remove()
    e=observed['endpoint']; a=shadow.artifact()
    hidden=math.fsum(w*(float(x)-m)/s for w,x,m,s in zip(a['hidden_coef'],e,a['hidden_mean'],a['hidden_scale']))
    feature=numerical(problem); valid=True; hashes={'endpoint':hashlib.sha256(e.tobytes()).hexdigest()}
    if need:
        valid=bool(mask) and 'lexical' in observed and 'contextual' in observed
        if valid:
            l,c=observed['lexical'],observed['contextual']
            # Frozen scalar arithmetic used float64 vectors after FP32 pooling.
            alignment=anchored_alignment(l,c,e)
            valid=alignment is not None
            if valid: feature.append(alignment)
            hashes.update(lexical=hashlib.sha256(l.tobytes()).hexdigest(),contextual=hashlib.sha256(c.tobytes()).hexdigest())
    valid=bool(valid and all(math.isfinite(x) for x in feature))
    torch.cuda.synchronize(); elapsed=time.perf_counter()-start
    MEASUREMENTS['forwards']+=1; MEASUREMENTS['forward_seconds']+=elapsed
    record=dict(hidden=hidden,features=feature,valid=valid,hashes=hashes,
        input_ids_hash=digest(ids),mask_hash=digest(mask),prompt_hash=digest(prompt),
        tokens=len(ids),selected_tokens=len(mask),seconds=elapsed)
    if OBSERVER is not None: OBSERVER(problem,record)
    return record


def corrected_probability(raw_margin,features):
    a=correction(); head=a['head']
    p=1/(1+math.exp(-raw_margin)) if raw_margin>=0 else math.exp(raw_margin)/(1+math.exp(raw_margin))
    p=min(1-1e-8,max(1e-8,p)); z=math.log(p/(1-p))
    raw=[z]+features
    shift=head['coef'][0]+math.fsum(w*(x-m)/s for w,x,m,s in zip(head['coef'][1:],raw,head['mean'],head['scale']))
    score=z+shift
    return 1/(1+math.exp(-score)) if score>=0 else math.exp(score)/(1+math.exp(score))


def predict_probability(model_id,reasoning_effort,problem):
    observed=measure(problem)
    margin=shadow._score(model_id,reasoning_effort,problem,observed['hidden'])
    if reasoning_effort!='default' or not observed['valid']:
        MEASUREMENTS['fallback_predictions']+=1
        probability=(1/(1+math.exp(-margin)) if margin>=0 else math.exp(margin)/(1+math.exp(margin)))
        # Preserve shadow's margin>=0 decision even when sigmoid rounds to.5.
        return math.nextafter(.5,0.) if margin<0 and probability>=.5 else probability
    return corrected_probability(margin,observed['features'])


def are_robust(model_id: str,reasoning_effort: str,problems: list[str])->list[bool]:
    if model_id not in MODELS: raise ValueError('unsupported Small Models checkpoint')
    MEASUREMENTS['predictions']+=len(problems)
    return [bool(predict_probability(model_id,reasoning_effort,p)>=.5) for p in problems]
